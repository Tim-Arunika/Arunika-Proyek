import json
import datetime
import os
import textwrap
from collections import defaultdict


def wrap_text(text, width):
    return textwrap.wrap(str(text), width=width) if text else [""]


def print_table_with_wrap(data, headers, max_widths):
    header_line = "| " + " | ".join(
        h.ljust(max_widths[h]) for h in headers
    ) + " |"
    print(header_line)

    print("|-" + "-|-".join("-" * max_widths[h] for h in headers) + "-|")

    for row in data:
        wrapped_columns = []
        max_lines = 1

        for h in headers:
            lines = wrap_text(row.get(h, ""), max_widths[h])
            wrapped_columns.append(lines)
            max_lines = max(max_lines, len(lines))

        for i in range(max_lines):
            line = "| "
            for idx, h in enumerate(headers):
                col_lines = wrapped_columns[idx]
                text = col_lines[i] if i < len(col_lines) else ""
                line += text.ljust(max_widths[h]) + " | "
            print(line)


#laporan keuangan
def data_keuangan():
    nama_file = "data_pemasukan_&_pengeluaran.json"

    if not os.path.exists(nama_file):
        print("File data tidak ditemukan.")
        return

    with open(nama_file, "r") as f:
        data = json.load(f)

    # Group by (tahun, bulan)
    grup = defaultdict(list)

    for d in data:
        tgl_obj = datetime.datetime.strptime(d["Tanggal"], "%d-%m-%Y")
        key = (tgl_obj.year, tgl_obj.month)
        grup[key].append(d)

    # Urut berdasarkan tahun → bulan
    urutan = sorted(grup.keys())

    headers = ["Tanggal", "Tipe", "Jumlah", "Barang", "Kategori", "Deskripsi"]
    max_widths = {
        "Tanggal": 12,
        "Tipe": 8,
        "Jumlah": 10,
        "Barang": 15,
        "Kategori": 12,
        "Deskripsi": 40
    }

    nama_bulan = [
        "", "Januari", "Februari", "Maret", "April", "Mei", "Juni",
        "Juli", "Agustus", "September", "Oktober", "November", "Desember"
    ]
    #judul program

    print("\n=====================================")
    print("              DATA KEUANGAN")
    print("=====================================\n")

    # cetak tabel perbulan
    for tahun, bulan in urutan:
        daftar = grup[(tahun, bulan)]

        total_masuk = 0
        total_keluar = 0
        hasil = []

        for d in daftar:
            row = {
                "Tanggal": d["Tanggal"],
                "Tipe": d["Tipe"],
                "Jumlah": d["Jumlah"],
                "Barang": d.get("Barang", "") if d["Tipe"].lower() == "keluar" else "",
                "Kategori": d.get("Kategori", "") if d["Tipe"].lower() == "keluar" else "",
                "Deskripsi": d.get("Deskripsi", "") if d["Tipe"].lower() == "keluar" else "",
            }

            if d["Tipe"].lower() == "keluar":
                total_keluar += float(d["Jumlah"])
            else:
                total_masuk += float(d["Jumlah"])

            hasil.append(row)

        # judul setiap tabel laporan
        print(f"\nBulan: {nama_bulan[bulan]} {tahun}")
        print("-" * 116)

        # tabel data keuangan
        print_table_with_wrap(hasil, headers, max_widths)

        # ringkasan laporan keuangan perbulan
        print("\n\n")
        print("-" * 29)
        print(f"|Total Pemasukan  : {total_masuk}")
        print("-" * 29)
        print(f"|Total Pengeluaran: {total_keluar}")
        print("-" * 29)
        print(f"|Sisa Saldo       : {total_masuk - total_keluar}")
        print("-" * 29)

    print("\nJika tidak muncul data keuangan, maka kami tidak memiliki data riwayat keuangan anda, cobalah untuk catat keuangan terlebih dahulu")
    input("\nTekan enter untuk kembali ke beranda: ")