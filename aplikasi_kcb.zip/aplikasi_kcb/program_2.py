import json
import datetime
import os
#fungsi untuk menambah pemasukan
def tambah_pengeluaran():
    while True:
        nama_file_keuangan = "data_pemasukan_&_pengeluaran.json"
        # pastikan file ada, kalau tidak buat baru
        if not os.path.exists(nama_file_keuangan):
            with open(nama_file_keuangan, "w") as f:
                json.dump([], f)

        print("\nJika anda ingin membatalkan program catat pengeluaran,\nsilahkan enter kosong tanpa input atau input yang terdapat non angka, \nbaik simbol maupun huruf bisa juga campuran dengan angka.\n")
        jumlah_pengeluaran = input("Masukkan nominal pengeluaran: ")
        while True:
            # 1. Enter kosong → keluar dari fungsi
            if jumlah_pengeluaran == "":
                print("Baik tuan, anda membatalkan program catat pengeluaran.")
                return

            # 2. Full angka (valid) → lanjutkan program
            elif jumlah_pengeluaran.isdigit():
                jumlah_pengeluaran = float(jumlah_pengeluaran)
                barang = input("Masukkan nama barang: ")
                kategori = input("Masukkan kategori (misal:kesehatan, makanan, minuman, dan lain-lain): ")
                deskripsi = input("Masukkan deskripsi: ")
                # membaca file data pemasukan
                with open(nama_file_keuangan, "r") as f:
                    data = json.load(f)
                # saldo terakhir
                saldo_terakhir = data[-1]["Sisa saldo"] if data else 0
                # menghitung saldo baru
                saldo_baru = saldo_terakhir - jumlah_pengeluaran
                # data yang di tulis di file data pemasukan
                print(f"Saldo baru Rp.{saldo_baru : .2f}")
                data_baru = {
                    "Tanggal": datetime.date.today().strftime("%d-%m-%Y"),
                    "Tipe": "Keluar",
                    "Barang": barang,
                    "Kategori": kategori,
                    "Deskripsi": deskripsi,
                    "Jumlah": jumlah_pengeluaran,
                    "Sisa saldo": saldo_baru
                }
                # simpan data
                data.append(data_baru)
                with open(nama_file_keuangan, "w") as f:
                    json.dump(data, f, indent=4)
                # memberitahu user bahwa data pemasukan sudah tersimpan
                print(f"Pengeluaran tersimpan. Saldo saat ini: RP. {saldo_baru : .2f}")
                break

            # 3. Selain itu → keluar dari fungsi
            else:
                print("Baik tuan, anda membatalkan program catat pengeluaran.")
                return

