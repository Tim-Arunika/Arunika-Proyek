import json
import datetime
import os
#fungsi untuk mencatat pemasukan
def tabungan_masuk():
    while True:
        # nama file untuk menyimpan data keuangan
        nama_file_tabungan = "data_tabungan.json"

        # pastikan file ada, kalau tidak buat baru
        if not os.path.exists(nama_file_tabungan):
            with open(nama_file_tabungan, "w") as f:
                json.dump([], f)

        while True:
            print("\nJika anda ingin membatalkan program catat tabungan masuk,\nsilahkan enter kosong tanpa input atau input yang terdapat non angka, \nbaik simbol maupun huruf bisa juga campuran dengan angka.\n")
            jumlah_tabungan_masuk = input("Masukkan nominal tabungan masuk: ")

            # 1. Enter kosong → keluar dari fungsi
            if jumlah_tabungan_masuk == "":
                print("Baik tuan, anda membatalkan program catat tabungan masuk.")
                return

            # 2. Full angka (valid) → lanjutkan fungsi
            elif jumlah_tabungan_masuk.isdigit():
                jumlah_tabungan_masuk = float(jumlah_tabungan_masuk)
                break

            # 3. Selain itu → keluar dari fungsi
            else:
                print("Baik tuan, anda membatalkan program catat tabungan masuk.")
                return

        # baca file data
        with open(nama_file_tabungan, "r") as f:
            data = json.load(f)

        # saldo terakhir
        saldo_terakhir = data[-1]["Sisa saldo"] if data else 0

        # hitung saldo baru
        saldo_baru = saldo_terakhir + jumlah_tabungan_masuk

        # data baru
        data_baru = {
            "Tanggal": datetime.date.today().strftime("%d-%m-%Y"),
            "Tipe": "Masuk",
            "Jumlah": jumlah_tabungan_masuk,
            "Sisa saldo": saldo_baru
        }

        # simpan data
        data.append(data_baru)
        with open(nama_file_tabungan, "w") as f:
            json.dump(data, f, indent=4)

        print(f"Tabungan masuk tersimpan. Saldo saat ini: Rp {saldo_baru:.2f}")
