#import file yang dibutuhkan
import shutil
import program_1
import program_2
import program_3
import program_4
import program_5
import program_6

# di bawah ini adalah hiasan untuk output program
# variabel cols untuk mengetahui ukuran terminal, yang dijalankan oleh device
cols = shutil.get_terminal_size().columns
print("___________".center(cols))
print("______________________".center(cols))
print("___________".center(cols))
print("=" * cols)
print("\n")
print("KCB".center(cols))
print("(Keuangan Cerdas Berkelanjutan)".center(cols))
print("\n")
print("Asisten Keuangan Pribadi Anda".center(cols))
print("\n")
print("=" * cols)

#beranda program
print("\nSaya adalah asisten keuangan pribadi anda.\nberikut beberapa opsi bantuan yang dapat saya kerjakan \U0001F525\U0001F525\U0001F525.")

#program yang tersedia & pilihan user tentang program yang ingin di eksekusi
while True:
    print("\n")
    print("opsi yang tersedia." .center(cols))
    print("\n\n1.catat pemasukan. \n2.catat pengeluaran. \n3.catat tabungan masuk. \n4.catat tabungan keluar \n5.lihat data pemasukan dan pengeluaran. \n6.lihat data tabungan. \n7.berhenti.".center(cols))
    pilihan = input("\nMasukkan pilihan anda: ")

    if pilihan == "1":
        print("Siap , anda memilih opsi 1 (catat pemasukan), \nakan saya laksanakan tuan")
        program_1.tambah_pemasukan()

    elif pilihan == "2" :
        print("Siap , anda memilih opsi 2 (catat pengeluaran), \nakan saya laksanakan tuan")
        program_2.tambah_pengeluaran()

    elif pilihan == "3" :
        print("Siap , anda memilih opsi 3 (catat tabungan masuk), \nakan saya laksanakan tuan")
        program_3.tabungan_masuk()

    elif pilihan == "4" :
        print("Siap , anda memilih opsi 4 (catat tabungan keluar), \nakan saya laksanakan tuan")
        program_4.tabungan_keluar()


    elif pilihan == "5" :
        print("Siap , anda memilih opsi 5 (lihat data pemasukan dan pengeluaran), \nakan saya laksanakan tuan")
        program_5.data_keuangan()

    elif pilihan == "6" :
        print("Siap , anda memilih opsi 6 (lihat data tabungan), \nakan saya laksanakan tuan")
        program_6.data_tabungan()

    elif pilihan == "7" :
        print("Siap , anda memilih opsi 7 (berhenti), \nakan saya laksanakan tuan")
        print("sampai bertemu di lain waktu tuan")
        break
    else :
         
         print("pilihan tidak tersedia, silahkan masukkan opsi \nyang tersedia !!! (1, 2, 3, 4, 5, 6, 7)")
        
