import json
import datetime
import os
#fungsi untuk mencatat pemasukan
def tambah_pemasukan():
    while True:
        # nama file untuk menyimpan data keuangan
        nama_file_keuangan = "data_pemasukan_&_pengeluaran.json"

        # pastikan file ada, kalau tidak buat baru
        if not os.path.exists(nama_file_keuangan):
            with open(nama_file_keuangan, "w") as f:
                json.dump([], f)

        while True:
            print("\nJika anda ingin membatalkan program catat pemasukan,\nsilahkan enter kosong tanpa input atau input yang terdapat non angka, \nbaik simbol maupun huruf bisa juga campuran dengan angka.\n")
            jumlah_pemasukan = input("Masukkan nominal pemasukan: ")

            # 1. Enter kosong → keluar dari fungsi
            if jumlah_pemasukan == "":
                print("Baik tuan, anda membatalkan program catat pemasukan.")
                return

            # 2. Full angka (valid) → lanjutkan fungsi
            elif jumlah_pemasukan.isdigit():
                jumlah_pemasukan = float(jumlah_pemasukan)
                break

            # 3. Selain itu → keluar dari fungsi
            else:
                print("Baik tuan, anda membatalkan program catat pemasukan.")
                return

        # baca file data
        with open(nama_file_keuangan, "r") as f:
            data = json.load(f)

        # saldo terakhir
        saldo_terakhir = data[-1]["Sisa saldo"] if data else 0

        # hitung saldo baru
        saldo_baru = saldo_terakhir + jumlah_pemasukan

        # data baru
        data_baru = {
            "Tanggal": datetime.date.today().strftime("%d-%m-%Y"),
            "Tipe": "Masuk",
            "Jumlah": jumlah_pemasukan,
            "Sisa saldo": saldo_baru
        }

        # simpan data
        data.append(data_baru)
        with open(nama_file_keuangan, "w") as f:
            json.dump(data, f, indent=4)

        print(f"Pemasukan tersimpan. Saldo saat ini: Rp {saldo_baru:.2f}")

