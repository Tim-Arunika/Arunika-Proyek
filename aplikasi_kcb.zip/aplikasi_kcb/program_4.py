import json
import datetime
import os
#fungsi untuk menambah pemasukan
def tabungan_keluar():
    while True:
        nama_file_tabungan = "data_tabungan.json"
        # pastikan file ada, kalau tidak buat baru
        if not os.path.exists(nama_file_tabungan):
            print("Maaf tuan \U0001F64F\U0001F64F\U0001F64F, kami tidak memiliki data tabungan masuk, anda harus mencatat tabungan sebelum mencatat tabungan keluar.")
            return

        print("\nJika anda ingin membatalkan program catat tabungan keluar,\nsilahkan enter kosong tanpa input atau input yang terdapat non angka, \nbaik simbol maupun huruf bisa juga campuran dengan angka.\n")
        jumlah_tabungan_keluar = input("Masukkan nominal tabungan keluar: ")
        while True:
            # 1. Enter kosong → keluar dari fungsi
            if jumlah_tabungan_keluar == "":
                print("Baik tuan, anda membatalkan program catat tabungan keluar.")
                return

            # 2. Full angka (valid) → lanjutkan program
            elif jumlah_tabungan_keluar.isdigit():
                jumlah_tabungan_keluar = float(jumlah_tabungan_keluar)
                # membaca file data pemasukan
                with open(nama_file_tabungan, "r") as f:
                    data = json.load(f)
                # saldo terakhir
                saldo_terakhir = data[-1]["Sisa saldo"] if data else 0
                if jumlah_tabungan_keluar > saldo_terakhir:
                    print(f"Maaf tuan \U0001F64F\U0001F64F\U0001F64F, jumlah tabungan keluar melebihi sisa saldo tabungan saat ini!!!.\n Sisa saldo saat ini:{saldo_terakhir}")
                    return
                # menghitung saldo baru
                saldo_baru = saldo_terakhir - jumlah_tabungan_keluar
                # data yang di tulis di file data pemasukan
                print(f"Saldo baru Rp.{saldo_baru : .2f}")
                data_baru = {
                    "Tanggal": datetime.date.today().strftime("%d-%m-%Y"),
                    "Tipe": "Keluar",
                    "Jumlah": jumlah_tabungan_keluar,
                    "Sisa saldo": saldo_baru
                }
                # simpan data
                data.append(data_baru)
                with open(nama_file_tabungan, "w") as f:
                    json.dump(data, f, indent=4)
                # memberitahu user bahwa data pemasukan sudah tersimpan
                print(f"Tabungan keluar tersimpan. Saldo saat ini: RP. {saldo_baru : .2f}")
                break

            # 3. Selain itu → keluar dari fungsi
            else:
                print("Baik tuan, anda membatalkan program catat tabungan keluar.")
                return

